# HolaAvalonia

Proyecto de escritorio Avalonia para la práctica 3.1.

## Ejecutar

Abre `HolaAvalonia.csproj` en Visual Studio Code y ejecuta `dotnet run` desde la terminal integrada.

La ventana principal combina XAML y C#: el botón «Púlsame» cambia el saludo y el botón «Botón creado en C#» abre `VentanaCS`, construida íntegramente en C#.
